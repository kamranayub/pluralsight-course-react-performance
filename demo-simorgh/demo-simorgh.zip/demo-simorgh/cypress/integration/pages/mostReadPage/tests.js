import { crossPlatform as mostReadAssertions } from './mostReadAssertions';

export default ({ service, variant }) => {
  mostReadAssertions({ service, variant });
};
