# Helpers

These should be avoided wherever possible. In particular if you can make it a cypress command, add one [here](../commands)
