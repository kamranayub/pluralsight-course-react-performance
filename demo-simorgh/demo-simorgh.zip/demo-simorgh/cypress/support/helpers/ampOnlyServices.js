const ampOnlyServices = ['news', 'sport', 'newsround'];
export { ampOnlyServices as default };
