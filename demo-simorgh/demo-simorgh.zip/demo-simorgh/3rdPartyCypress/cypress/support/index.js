import './commands';

Cypress.Screenshot.defaults({
  screenshotOnRunFailure: false,
});
